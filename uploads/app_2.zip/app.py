import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import  mean_absolute_error, r2_score
import streamlit as st
import pickle
import numpy as np
from sklearn.model_selection import GridSearchCV
from st_circular_progress import CircularProgress

df=pd.read_excel("D://newmoli.xlsx")
# print(df.columns)

label_encoder = LabelEncoder()

df['job_title_encoded'] = label_encoder.fit_transform(df['job_title'])



df=df[(df['rate']>58) &(df['rate']<=80)]
# df.to_csv("D://newmolidata.csv",index=False)

X=df[['entity_id','certification','job_title_encoded']]
y=df['rate']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=49)

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), ['entity_id', 'certification','job_title_encoded'])
    ])

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('model', RandomForestRegressor(n_estimators=300, random_state=43))
])


pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)


# Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f'The r2 score is {r2}')
print(f'{mae}')


# print(df)



with open('pipeline.pkl', 'wb') as file:
    pickle.dump(pipeline, file)

with open('pipeline.pkl', 'rb') as file:
    loaded_pipeline = pickle.load(file)

# st.set_page_config(page_title="AlongX", page_icon=":rocket:")
# st.title('Rate Prediction model')



# languages = ['Select a language'] + df['job_title'].unique().tolist()
# selected_language = st.selectbox('Select language:',languages )
# # cities = ['Select a city'] + df['entity_name'].unique().tolist()
# # selected_entity = st.selectbox('Select city:', cities)
# certifications = ['Select a certification'] + df['certification_name'].unique().tolist()
# selected_certification = st.selectbox('Select certification:', certifications)


# if st.button('Calculate Rate'):
#     if selected_certification!="Select a certification" and selected_language!="Select a language":
        
#         def find_entity_id(selected_entity):
#             return int(df[df['entity_name'] == selected_entity]['entity_id'].unique().item())  
#         def find_certification_id(selected_certification):
#             return  int(df[df['certification_name'] == selected_certification]['certification'].unique().item())
#         def find_job_title_encoded(selected_entity):
#             return  int(df[df['job_title'] == selected_entity]['job_title_encoded'].unique().item())
        
#         entity_name=df['entity_name'].unique()
#         for name in entity_name:

#             input_data = pd.DataFrame({
#             'entity_id': find_entity_id(name),
#             'certification': find_certification_id(selected_certification),
#             'job_title_encoded': find_job_title_encoded(selected_language)
#         },index=[0])
            
#             predictions =loaded_pipeline.predict(input_data)
#             ceil=np.ceil(predictions)
#             format=int(ceil)
#             def round_to_nearest_5(n):
#                 return 5 * round(n / 5)
        
#         # Display predictions
#             st.success(f"The predicted rate for {name} is : {round_to_nearest_5(format)}")
#             # st.write(f"The accuracy is {int(r2*100)}%")
#         my_circular_progress = CircularProgress(
#         label="Accuracy",
#         value=int(r2*100),  # Set the progress value (0-100)
#         key="my_circular_progress")
#         my_circular_progress.st_circular_progress() 
    
#     else:
#         st.warning("Please select values from the dropdown.")
        
        
