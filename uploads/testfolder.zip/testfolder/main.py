from fastapi import FastAPI, HTTPException
from typing import List, Any, Dict
import httpx
import asyncio
from pydantic import BaseModel
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import AzureError
import pandas as pd
import io
import logging
from functools import lru_cache
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from datetime import datetime, timedelta
import time

# Set up logging with custom format including timestamp
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = FastAPI()
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Configuration
AZURE_ML_ENDPOINT = "https://moli-ai-dev-ws3-ml-uzabg.westus3.inference.ml.azure.com/score"
BEARER_TOKEN = "hbhEYHNEd1n5ArUJMRgnhtXmvzD7BZu6"
AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=stmoliaihub774999322363;AccountKey=5zbHRn/VU9x4BlIz9ZH9ngZvGTyXjp0jB6pOXaLldGAMy1P4QTyRNP8g6/bC1gmN2xiCOQe+2Unm+AStUVApoA==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "excel"
EXCEL_FILE_NAME = "NewData.xlsx"

# Global httpx client for connection pooling
http_client = httpx.AsyncClient(
    timeout=30.0,
    limits=httpx.Limits(max_keepalive_connections=20, max_connections=50)
)

class Certificate(BaseModel):
    id: int
    name: str

class PredictionResponse(BaseModel):
    certificate: int
    certificate_name: str
    predicted_rate: float

class CachedData:
    def __init__(self):
        self.certificates: List[Certificate] = []
        self.last_update: datetime = datetime.min
        self.cache_duration = timedelta(minutes=5)

    def is_cache_valid(self) -> bool:
        return (datetime.now() - self.last_update) < self.cache_duration

cached_data = CachedData()

class BlobStorageService:
    def __init__(self):
        try:
            self.blob_service_client = BlobServiceClient.from_connection_string(
                AZURE_STORAGE_CONNECTION_STRING
            )
            self.container_client = self.blob_service_client.get_container_client(
                CONTAINER_NAME
            )
        except Exception as e:
            logger.error(f"Failed to initialize blob service: {str(e)}")
            raise

    async def get_certificates(self) -> List[Certificate]:
        """
        Read certificates from Excel file in blob storage with caching
        """
        start_time = time.time()
        try:
            # Check cache first
            if cached_data.is_cache_valid():
                cache_time = time.time() - start_time
                logger.info(f"Cache hit! Returned certificates in {cache_time:.3f} seconds")
                return cached_data.certificates

            # Download the Excel file
            download_start = time.time()
            blob_client = self.container_client.get_blob_client(EXCEL_FILE_NAME)
            excel_data = await asyncio.to_thread(blob_client.download_blob().readall)
            download_time = time.time() - download_start
            logger.info(f"Excel file downloaded in {download_time:.3f} seconds")
            
            # Read Excel file into pandas DataFrame
            parse_start = time.time()
            df = await asyncio.to_thread(
                pd.read_excel,
                io.BytesIO(excel_data),
                usecols=['certificate', 'certificate_name']
            )
            parse_time = time.time() - parse_start
            logger.info(f"Excel file parsed in {parse_time:.3f} seconds")
            
            # Convert DataFrame to list of Certificate objects
            convert_start = time.time()
            certificates = [
                Certificate(
                    id=int(row['certificate']),
                    name=str(row['certificate_name']).strip()
                )
                for _, row in df.iterrows()
            ]
            
            # Update cache
            cached_data.certificates = certificates
            cached_data.last_update = datetime.now()
            
            convert_time = time.time() - convert_start
            total_time = time.time() - start_time
            logger.info(f"Data conversion completed in {convert_time:.3f} seconds")
            logger.info(f"Total certificates processing time: {total_time:.3f} seconds")
            return certificates
            
        except Exception as e:
            logger.error(f"Error reading Excel file from blob storage: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Error reading certificate data: {str(e)}"
            )

async def get_predictions_batch(certificates: List[Certificate], lang_id: int, batch_num: int) -> List[float]:
    """Make a batched prediction request to Azure ML endpoint"""
    start_time = time.time()
    headers = {
        "Authorization": f"Bearer {BEARER_TOKEN}",
        "Content-Type": "application/json"
    }
    
    # Prepare batch payload
    payload = {
        "input_data": {
            "columns": ["certificate", "lang_id"],
            "data": [[cert.id, lang_id] for cert in certificates],
            "index": list(range(len(certificates)))
        }
    }
    
    try:
        response = await http_client.post(
            AZURE_ML_ENDPOINT,
            headers=headers,
            json=payload
        )
        response.raise_for_status()
        elapsed_time = time.time() - start_time
        logger.info(f"Batch {batch_num} predictions completed in {elapsed_time:.3f} seconds for {len(certificates)} certificates")
        return response.json()
    except Exception as e:
        logger.error(f"Error getting predictions batch {batch_num}: {str(e)}")
        raise

@app.post("/predict/{lang_id}")
async def predict_multiple(lang_id: int) -> JSONResponse:
    """
    Get predictions for all certificates from Excel file for a given language ID
    """
    overall_start = time.time()
    try:
        # Initialize blob storage service and get certificates
        cert_start = time.time()
        blob_service = BlobStorageService()
        certificates = await blob_service.get_certificates()
        cert_time = time.time() - cert_start
        logger.info(f"Certificates retrieved in {cert_time:.3f} seconds")
        
        if not certificates:
            logger.warning("No certificates found in Excel file")
            return JSONResponse(content=[])

        # Get predictions in batches
        BATCH_SIZE = 50
        all_predictions = []
        
        # Process batches with timing
        pred_start = time.time()
        for i in range(0, len(certificates), BATCH_SIZE):
            batch = certificates[i:i + BATCH_SIZE]
            batch_num = i // BATCH_SIZE + 1
            predictions = await get_predictions_batch(batch, lang_id, batch_num)
            all_predictions.extend(predictions)
        
        pred_time = time.time() - pred_start
        logger.info(f"All predictions completed in {pred_time:.3f} seconds")
        
        # Format the responses
        format_start = time.time()
        response = [
            {
                "certificate": cert.id,
                "certificate_name": cert.name,
                "predicted_rate": pred
            }
            for cert, pred in zip(certificates, all_predictions)
        ]
        format_time = time.time() - format_start
        
        total_time = time.time() - overall_start
        logger.info(f"Response formatting completed in {format_time:.3f} seconds")
        logger.info(f"Total API request completed in {total_time:.3f} seconds")
        
        return JSONResponse(content=response)
        
    except Exception as e:
        error_time = time.time() - overall_start
        logger.error(f"Error in predict_multiple after {error_time:.3f} seconds: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/certificates")
async def get_certificates() -> JSONResponse:
    """Return the list of available certificates from Excel file"""
    start_time = time.time()
    try:
        blob_service = BlobStorageService()
        certificates = await blob_service.get_certificates()
        response = JSONResponse(content=[cert.dict() for cert in certificates])
        elapsed_time = time.time() - start_time
        logger.info(f"Certificates endpoint completed in {elapsed_time:.3f} seconds")
        return response
    except Exception as e:
        error_time = time.time() - start_time
        logger.error(f"Error in get_certificates endpoint after {error_time:.3f} seconds: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
    
    
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

#-------------------------------------------------------------------------------------------------------------

# import requests
# import pandas as pd
# from azure.storage.blob import BlobServiceClient
# from fastapi import FastAPI
# from pydantic import BaseModel
# from typing import List
# import time

# # Azure Blob Storage connection details
# AZURE_STORAGE_CONNECTION_STRING ="DefaultEndpointsProtocol=https;AccountName=stmoliaihub774999322363;AccountKey=5zbHRn/VU9x4BlIz9ZH9ngZvGTyXjp0jB6pOXaLldGAMy1P4QTyRNP8g6/bC1gmN2xiCOQe+2Unm+AStUVApoA==;EndpointSuffix=core.windows.net"
# CONTAINER_NAME = "excel"
# BLOB_NAME = "NewData.xlsx"

# # Define the FastAPI app
# app = FastAPI()

# # Define the input data model
# class InputData(BaseModel):
#     columns: List[str]
#     data: List[List[float]]
#     index: List[int]

# class PredictionRequest(BaseModel):
#     input_data: InputData

# class PredictionResponse(BaseModel):
#     certificate: int
#     certificate_name: str
#     predicted_rate: float

# # Azure Machine Learning endpoint URL and key
# AZURE_ENDPOINT_URL = "https://moli-ai-dev-ws3-ml-qousf.westus3.inference.ml.azure.com/score"
# AZURE_API_KEY = "47ageYH6ovqUvgamzeGP36lz6Z8S68me"

# def fetch_data_from_blob():
#     # Create the BlobServiceClient object
#     blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
    
#     # Get the container client
#     container_client = blob_service_client.get_container_client(CONTAINER_NAME)
    
#     # Get the blob client
#     blob_client = container_client.get_blob_client(BLOB_NAME)
    
#     # Download the blob content to a local file
#     blob_data = blob_client.download_blob().readall()
    
#     # Load the data into a DataFrame
#     df = pd.read_excel(pd.io.common.BytesIO(blob_data))
#     return df

# @app.post("/predict", response_model=List[PredictionResponse])
# def predict(request: PredictionRequest):

#     start_time = time.time()
#     # Fetch data from Azure Blob Storage
#     df = fetch_data_from_blob()

#     # Extract columns and data from the input JSON
#     columns = request.input_data.columns
#     input_data = request.input_data.data

#     # Convert the input data to a DataFrame
#     input_df = pd.DataFrame(data=input_data, columns=columns)

#     # Prepare the data for the Azure endpoint
#     results = []
#     certifications = df[['certificate', 'certificate_name']].drop_duplicates()
#     for _, row in certifications.iterrows():
#         cert = row['certificate']
#         cert_name = row['certificate_name']
#         input_df['certificate'] = cert
#         input_data_scaled = input_df.values.tolist()
#         azure_input_data = {
#             "input_data": {
#                 "columns": columns + ['certificate'],
#                 "data": input_data_scaled,
#                 "index": request.input_data.index
#             }
#         }

#         # Set the headers for the request
#         headers = {
#             "Content-Type": "application/json",
#             "Authorization": f"Bearer {AZURE_API_KEY}"
#         }

#         # Make the request to the Azure endpoint
#         response = requests.post(AZURE_ENDPOINT_URL, json=azure_input_data, headers=headers)

#         # Debugging information
#         print(f"Request data: {azure_input_data}")
#         print(f"Response status code: {response.status_code}")
#         print(f"Response content: {response.content}")

#         # Check if the request was successful
#         if response.status_code == 200:
#             predictions = response.json()
#             for i, pred in enumerate(predictions):
#                 results.append(PredictionResponse(certificate=cert, certificate_name=cert_name, predicted_rate=pred))
#         else:
#             return {"error": f"Failed to get predictions from Azure endpoint: {response.content}"}
#     end_time = time.time()
#     print(f"Total time taken: {end_time - start_time} seconds")

#     return results

# # Example usage
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
#-----------------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------
# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# from typing import List
# import pandas as pd
# from azure.storage.blob import BlobServiceClient
# import asyncio
# import aiohttp
# import time

# # Azure Blob Storage connection details
# AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=stmoliaihub774999322363;AccountKey=5zbHRn/VU9x4BlIz9ZH9ngZvGTyXjp0jB6pOXaLldGAMy1P4QTyRNP8g6/bC1gmN2xiCOQe+2Unm+AStUVApoA==;EndpointSuffix=core.windows.net"
# CONTAINER_NAME = "excel"
# BLOB_NAME = "NewData.xlsx"

# # Define the FastAPI app
# app = FastAPI()

# # Define the input data model
# class InputData(BaseModel):
#     columns: List[str]
#     data: List[List[float]]
#     index: List[int]

# class PredictionRequest(BaseModel):
#     input_data: InputData

# class PredictionResponse(BaseModel):
#     certificate: int
#     certificate_name: str
#     predicted_rate: float

# # Azure Machine Learning endpoint URL and key
# AZURE_ENDPOINT_URL = "https://moli-ai-dev-ws3-ml-uzabg.westus3.inference.ml.azure.com/score"
# AZURE_API_KEY = "hbhEYHNEd1n5ArUJMRgnhtXmvzD7BZu6"

# # Cache the data to avoid fetching it every time
# cached_df = None

# def fetch_data_from_blob():
#     global cached_df
#     if cached_df is None:
#         # Create the BlobServiceClient object
#         blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
        
#         # Get the container client
#         container_client = blob_service_client.get_container_client(CONTAINER_NAME)
        
#         # Get the blob client
#         blob_client = container_client.get_blob_client(BLOB_NAME)
        
#         # Download the blob content to a local file
#         blob_data = blob_client.download_blob().readall()
        
#         # Load the data into a DataFrame
#         cached_df = pd.read_excel(pd.io.common.BytesIO(blob_data))
#     return cached_df

# async def make_request(session, azure_input_data):
#     headers = {
#         "Content-Type": "application/json",
#         "Authorization": f"Bearer {AZURE_API_KEY}"
#     }
#     async with session.post(AZURE_ENDPOINT_URL, json=azure_input_data, headers=headers) as response:
#         response_data = await response.json()
#         print("Response from Azure ML endpoint:", response_data)  # Debugging line
#         return response_data

# @app.post("/predict", response_model=List[PredictionResponse])
# async def predict(request: PredictionRequest):
#     start_time = time.time()
    
#     # Fetch data from Azure Blob Storage
#     df = fetch_data_from_blob()

#     # Extract columns and data from the input JSON
#     columns = request.input_data.columns
#     input_data = request.input_data.data

#     # Convert the input data to a DataFrame
#     input_df = pd.DataFrame(data=input_data, columns=columns)

#     # Prepare the data for the Azure endpoint
#     results = []
#     certifications = df[['certificate', 'certificate_name']]
#     async with aiohttp.ClientSession() as session:
#         tasks = []
#         for _, row in certifications.iterrows():
#             cert = row['certificate']
#             cert_name = row['certificate_name']
#             input_df['certificate'] = cert
#             input_data_scaled = input_df.values.tolist()
#             azure_input_data = {
#                 "input_data": {
#                     "columns": columns + ['certificate'],
#                     "data": input_data_scaled,
#                     "index": request.input_data.index
#                 }
#             }
#             tasks.append(make_request(session, azure_input_data))

#         responses = await asyncio.gather(*tasks)
#         for i, response in enumerate(responses):
#             cert = certifications.iloc[i]['certificate']
#             cert_name = certifications.iloc[i]['certificate_name']
#             for pred in response:
#                 try:
#                     predicted_rate = float(pred)  # Ensure the value is a float
#                     results.append(PredictionResponse(certificate=cert, certificate_name=cert_name, predicted_rate=predicted_rate))
#                 except ValueError:
#                     print(f"Invalid predicted rate: {pred}")  # Debugging line

#     end_time = time.time()
#     print(f"Total time taken: {end_time - start_time} seconds")
    
#     return results

# # Example usage
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)


#-----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------
#time---------------------------------------------------------------------------------------time
#-----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------





# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# import httpx
# import time

# app = FastAPI()

# # Define the request body using Pydantic
# class InputData(BaseModel):
#     columns: list[str]
#     data: list[list[float]]
#     index: list[int]

# class PredictionRequest(BaseModel):
#     input_data: InputData

# # Replace with your actual Azure endpoint and bearer token
# AZURE_ENDPOINT = "https://moli-ai-dev-ws3-ml-izgzg.westus3.inference.ml.azure.com/score"
# BEARER_TOKEN = "WPqNLpF7kRu3QMoT0Sg5c7Jm3GpbElIl"

# @app.post("/predict")
# async def predict(request: PredictionRequest):
    
#     start_time = time.time()
#     headers = {
#         "Authorization": f"Bearer {BEARER_TOKEN}",
#         "Content-Type": "application/json"
#     }
#     try:
#         async with httpx.AsyncClient() as client:
#             response = await client.post(AZURE_ENDPOINT, json=request.model_dump(), headers=headers)
#             response.raise_for_status()
#             prediction = response.json()
            
#             # Assuming the prediction result is a list with a single value
#             prediction_value = prediction[0]
#             end_time = time.time()
#             print(f"Total time taken: {end_time - start_time} seconds")
#             if prediction_value == 1:
#                 return {"Time": "Above 12 hours"}
#             else:
#                 return {"Time": "Below 12 hours"}
#     except httpx.HTTPStatusError as e:
#         raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)

#NEW___________________________________________________________________________________________________________________NEW
#NEW___________________________________________________________________________________________________________________NEW
# from fastapi import FastAPI, HTTPException
# from azure.storage.blob import BlobServiceClient
# import requests
# import os
# from pydantic import BaseModel

# app = FastAPI()

# # Azure Blob Storage configuration
# blob_service_client = BlobServiceClient.from_connection_string("DefaultEndpointsProtocol=https;AccountName=stmoliaihub774999322363;AccountKey=5zbHRn/VU9x4BlIz9ZH9ngZvGTyXjp0jB6pOXaLldGAMy1P4QTyRNP8g6/bC1gmN2xiCOQe+2Unm+AStUVApoA==;EndpointSuffix=core.windows.net")
# container_name = "excel"

# # Azure ML endpoint and bearer token
# ml_endpoint = "https://moli-ai-dev-ws3-ml-uzabg.westus3.inference.ml.azure.com/score"
# bearer_token = "hbhEYHNEd1n5ArUJMRgnhtXmvzD7BZu6"

# class PredictionRequest(BaseModel):
#     lang_id: int

# def get_certificate_from_blob(certificate_id):
#     blob_client = blob_service_client.get_blob_client(container=container_name, blob=f"certificates/{certificate_id}.crt")
#     download_stream = blob_client.download_blob()
#     return download_stream.readall()

# @app.post("/predict")
# async def predict(lang_id: int):
#     try:
#         # Fetch the certificate from Azure Blob Storage
#         certificate = get_certificate_from_blob(lang_id)
        
#         # Prepare the data for the ML endpoint
#         input_data = {
#             "columns": ["certificate", "lang_id"],
#             "data": [[certificate, lang_id]],
#             "index": [0]
#         }
        
#         # Call the Azure ML endpoint
#         headers = {
#             "Authorization": f"Bearer {bearer_token}",
#             "Content-Type": "application/json"
#         }
#         response = requests.post(ml_endpoint, json=input_data, headers=headers)
        
#         if response.status_code != 200:
#             raise HTTPException(status_code=response.status_code, detail=response.text)
        
#         # Return the prediction result
#         result = response.json()
#         return {
#             "predicted_price": result["predicted_price"],
#             "certificate": result["certificate"],
#             "certificate_name": result["certificate_name"]
#         }
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)





# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# from typing import List
# import requests

# app = FastAPI()

# # Azure ML endpoint and bearer token
# ml_endpoint = "https://moli-ai-dev-ws3-ml-uzabg.westus3.inference.ml.azure.com/score"
# bearer_token = "hbhEYHNEd1n5ArUJMRgnhtXmvzD7BZu6"

# class LangIDRequest(BaseModel):
#     lang_id: int

# class PredictionResponse(BaseModel):
#     predicted_price: float
#     certificate: int
#     certificate_name: str

# # Predefined list of certificates
# certificates = [1, 2, 3]
# certificate_names = {1: "Certificate A", 2: "Certificate B", 3: "Certificate C"}

# @app.post("/predict", response_model=List[PredictionResponse])
# async def predict(request: LangIDRequest):
#     try:
#         results = []
#         for cert in certificates:
#             cert_name = certificate_names.get(cert, "Unknown Certificate")
            
#             # Prepare the data for the ML endpoint
#             input_data = {
#                 "columns": ["certificate", "lang_id"],
#                 "data": [[cert, request.lang_id]],
#                 "index": [0]
#             }
            
#             # Call the Azure ML endpoint
#             headers = {
#                 "Authorization": f"Bearer {bearer_token}",
#                 "Content-Type": "application/json"
#             }
#             response = requests.post(ml_endpoint, json=input_data, headers=headers)
            
#             if response.status_code != 200:
#                 raise HTTPException(status_code=response.status_code, detail=response.text)
            
#             # Parse the response
#             result = response.json()
#             results.append(PredictionResponse(
#                 predicted_price=result["predicted_price"],
#                 certificate=cert,
#                 certificate_name=cert_name
#             ))
        
#         return results
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
